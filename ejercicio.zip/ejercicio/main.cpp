#include <iostream>
#include "Cliente.h"
#include "Fecha.h"
#include "Abono.h"
#include "Cuenta.h"
#define TM 5

using namespace std;

void menu() {
    cout << " MENU DE OPCIONES" << endl;
    cout << "1. Agregar cliente a la lista" << endl;
    cout << "2. Agregar cuenta a la lista." << endl;
    cout << "3. Hacer abonos" << endl;
    cout << "4. Mostrar lista de clientes" << endl;
    cout << "5. Mostrar lista de cuentas" << endl;
    cout << "6. Mostrar detalles de la cuenta" << endl;
    cout << "7. Salir" << endl;
}

Cliente *agregarCliente() {
    int codigo;
    string nombre, apellido;
    cout << "Ingrese el codigo del cliente: ";
    cin >> codigo;
    cout << "Ingrese el nombre del cliente: ";
    cin >> nombre;
    cout << "Ingrese el apellido del cliente: ";
    cin >> apellido;
    Cliente *cl = new Cliente(codigo, nombre, apellido);
    return cl;
}

Cliente *buscarCliente(Cliente *lst[], int cont, int codigo) {
    bool encontrado = false;
    int contador = 0;
    Cliente *cl = NULL;
    while (contador < cont && !encontrado) {
        if (lst[contador]->getIdCliente() == codigo) {
            encontrado = true;
            cl = lst[contador];
        } else {
            contador++;
        }
    }
    return cl;
}

Cuenta *buscarCuenta(Cuenta *lst[], int cont, int nc) {
    bool encontrado = false;
    int contador = 0;
    Cuenta *cta = NULL;
    while (contador < cont && !encontrado) {
        if (lst[contador]->getNumeroCuenta() == nc) {
            encontrado = true;
            cta = lst[contador];
        } else {
            contador++;
        }
    }
    return cta;
}

Cuenta *agregarCuenta(Cliente *cl) {
    int nc;
    Cuenta *cta;
    cout << "Digite el numero de cuenta: ";
    cin >> nc;
    cta = new Cuenta(nc,cl);
    return cta;
}

void hacerAbono(Cuenta *cta) {
    int d, m, a;
    float ma;
    cout << "Digite la fecha de abono (dd/mm/aa): \n";
    cin >> d >> m >> a;
    cout << "Digite el monto del abono: ";
    cin >> ma;
    Fecha *fa = new Fecha(d, m, a);
   Abono *ab = new Abono(fa, ma);
    cta->agregarAbono(ab);
    delete fa;
}

void verDetalles(Cuenta *cta) {
    cout << "Numero de cuenta: " << cta->getNumeroCuenta() << endl;
    cout << "Cliente: " << cta->getCliente()->getNombre() << " " << cta->getCliente()->getApellido() << endl;
    cout << "Saldo: " << cta->getSaldo() << endl;
    if (cta->getContadorAbonos() == 0) {
        cout << "No hay abonos\n";
    } else {
        cout << "NO\tFecha\tMonto\n";
        Abono **lst = cta->getLstAbonos();
        for (int i = 0; i < cta->getContadorAbonos(); i++) {
            cout << (i + 1) << "\t";
            lst[i]->getFechaAbono()->mostrarFecha();
            cout << "\t" << lst[i]->getMontoAbono() << endl;
        }
    }
}

int main() {
    Cliente *lstclientes[TM];
    Cuenta *lstcuentas[TM];
    int contCli = 0, contCta = 0, idCl;
    Cliente *cl = NULL;
    Cuenta *cta = NULL;
    int opc = 0;

    do {
        menu();
        cin >> opc;
        system("cls");
        switch (opc) {
            case 1:
                if (contCli < TM) {
                    lstclientes[contCli] = agregarCliente();
                    contCli++;
                    cout << "Cliente agregado correctamente." << endl;
                } else {
                    cout << "La lista de clientes est� llena." << endl;
                }
                break;
            case 2:
                if (contCta < TM) {
                    cout << "Ingrese el codigo del cliente: ";
                    cin >> idCl;
                    cl = buscarCliente(lstclientes, contCli, idCl);
                    if (cl) {
                        lstcuentas[contCta] = agregarCuenta(cl);
                        contCta++;
                        cout << "La cuenta se agrego con exito\n";
                    } else {
                        cout << "El cliente no se encontro\n";
                    }
                } else {
                    cout << "La lista esta llena\n";
                }
                break;
            case 3:
                int idCta;
                cout << "Digite el numero de cuenta: ";
                cin >> idCta;
                cta = buscarCuenta(lstcuentas, contCta, idCta);
                if (cta) {
                    hacerAbono(cta);
                    cout << "El abono se agrego con exito\n";
                } else {
                    cout << "La cuenta no se encontro\n";
                }
                break;
            case 4:
                if (contCli == 0)
                    cout << "La lista esta vacia\n";
                else {
                    cout << "Id\tNombre\tApelllido\n";
                    for (int i = 0; i < contCli; i++) {
                        cout << lstclientes[i]->getIdCliente() << "\t";
                        cout << lstclientes[i]->getNombre() << "\t";
                        cout << lstclientes[i]->getApellido() << "\n";
                    }
                }
                break;
            case 5:
                if (contCta == 0)
                    cout << "La lista esta vacia\n";
                else {
                    cout << "Numero de cuenta\tNombre\tSaldo\n";
                    for (int i = 0; i < contCta; i++) {
                        cout << lstcuentas[i]->getNumeroCuenta() << "\t";
                        cout << lstcuentas[i]->getCliente()->getNombre() << " " << lstcuentas[i]->getCliente()->getApellido() << "\t";
                        cout << lstcuentas[i]->getSaldo() << "\n";
                    }
                }
                break;
            case 6:
                cout << "Digite el numero de cuenta: ";
                cin >> idCta;
                cta = buscarCuenta(lstcuentas, contCta, idCta);
                if (cta) {
                    verDetalles(cta);
                } else {
                    cout << "La cuenta no se encontro\n";
                }
                break;
            break;
            case 7: {
                cout << "Saliendo..." << endl;
                break;
            }
            default: {
                cout << "Opci�n invalida. Por favor ingrese una opci�n valida." << endl;
            }
        }
        //Marca de agua
       system("pause");
       system("cls");
    } while (opc != 7);
    return 0;
}
