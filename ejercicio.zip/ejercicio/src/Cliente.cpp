#include "Cliente.h"

Cliente::Cliente(int id, string nom, string ape){
    this->idCliente=id;
    this->nombre=nom;
    this->apellido=ape;
}

int Cliente::getIdCliente(){
    return idCliente;
}

string Cliente::getNombre(){
    return nombre;
}

string Cliente::getApellido(){
    return apellido;
}

Cliente::~Cliente()
{
    //dtor
}
