#include "Abono.h"
#include "Fecha.h"

Abono::Abono(Fecha *fecha, float monto) {
    this->fechaAbono = *fecha;
    this->montoAbono = monto;
}

Fecha* Abono::getFechaAbono() {
    return &fechaAbono;
}

float Abono::getMontoAbono() {
    return this->montoAbono;
}


Abono::~Abono() {
}
