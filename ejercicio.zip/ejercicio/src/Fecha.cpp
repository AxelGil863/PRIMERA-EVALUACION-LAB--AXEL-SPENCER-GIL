#include "Fecha.h"

Fecha::Fecha(){
}

Fecha::Fecha(int d, int m, int a)
{
   this->dia=d;
   this->mes=m;
   this->anio=a;
}
void Fecha::mostrarFecha(){
    cout<<dia<<"/"<<mes<<"/"<<anio;
}
Fecha::~Fecha()
{
    //dtor
}
