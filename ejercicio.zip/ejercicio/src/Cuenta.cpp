#include "Cuenta.h"
#include "Cliente.h"
#include "Abono.h"

Cuenta::Cuenta()
{

}



     Cuenta::Cuenta(int nc, Cliente *cl){
     this-> numeroCuenta=nc;
     this->cliente=cl;
     this-> contadorAbonos=0;
     this-> Saldo=0;
    }

    int Cuenta::getNumeroCuenta() {
        return this-> numeroCuenta;
    }
     void Cuenta::setNumeroCuenta(int nc) {
        this->numeroCuenta = nc;
    }
    Cliente* Cuenta::getCliente() {
        return this->cliente;
    }
    void Cuenta::setCliente(Cliente *cl) {
        this->cliente=cl;
    }
   bool Cuenta::agregarAbono(Abono *ab) {
    bool retorno = false;
    if (this->contadorAbonos < TAM) {
        this->lstAbonos[this->contadorAbonos] = ab;
        this->contadorAbonos++;
        this->Saldo += ab->getMontoAbono();
        retorno = true;
    }
    return retorno;
}

    Abono** Cuenta::getLstAbonos() {
        return this->lstAbonos;
    }
    float Cuenta::getSaldo() {
        return this->Saldo;
    }
     int Cuenta::getContadorAbonos() {
        return this->contadorAbonos;
    }

Cuenta::~Cuenta()
{
    //dtor
}
