#ifndef FECHA_H
#define FECHA_H
using namespace std;
#include <iostream>
#include <string.h>

class Fecha
{
    public:
        Fecha();
        Fecha(int,int,int);
        void mostrarFecha();
        virtual ~Fecha();

    protected:

    private:
        int dia;
        int mes;
        int anio;
};

#endif // FECHA_H
