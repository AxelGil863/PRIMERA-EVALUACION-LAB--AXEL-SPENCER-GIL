#ifndef ABONO_H
#define ABONO_H
#include "Fecha.h"
using namespace std;
#include <iostream>
#include <string.h>

class Abono
{
    public:
        Abono(Fecha* fecha, float monto);
        Fecha* getFechaAbono();
        float getMontoAbono();
        virtual ~Abono();

    protected:

    private:
        Fecha fechaAbono;
        float montoAbono;
};

#endif // ABONO_H
